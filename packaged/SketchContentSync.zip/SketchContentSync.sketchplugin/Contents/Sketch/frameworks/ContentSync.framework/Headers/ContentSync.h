//
//  ContentSync.h
//  ContentSync
//
//  Created by David Brody on 2/26/17.
//  Copyright © 2017 Syncify. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for ContentSync.
FOUNDATION_EXPORT double ContentSyncVersionNumber;

//! Project version string for ContentSync.
FOUNDATION_EXPORT const unsigned char ContentSyncVersionString[];

#import "ContentSyncPanelManager.h"

// In this header, you should import all the public headers of your framework using statements like #import <ContentSync/PublicHeader.h>


