var __globals = this;(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _context = require('../context');

var _context2 = _interopRequireDefault(_context);

var _framework_manager = require('../library/framework_manager');

var FrameworkManager = _interopRequireWildcard(_framework_manager);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Git File Name
 *
 * Returns the currently open and selected sketch file.
 */

exports.default = function (context) {
  (0, _context2.default)(context);
  FrameworkManager.loadContentSyncFramework();
  var main = ContentSyncPanelManager.alloc().init();
  var response = main.getFileName();
  log(response);
};

},{"../context":6,"../library/framework_manager":7}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.push = exports.pull = exports.openOSXApp = exports.getFileName = undefined;

var _getFileName = require('./getFileName.js');

var _getFileName2 = _interopRequireDefault(_getFileName);

var _openOSXApp = require('./openOSXApp.js');

var _openOSXApp2 = _interopRequireDefault(_openOSXApp);

var _pull = require('./pull.js');

var _pull2 = _interopRequireDefault(_pull);

var _push = require('./push.js');

var _push2 = _interopRequireDefault(_push);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.getFileName = _getFileName2.default;
exports.openOSXApp = _openOSXApp2.default;
exports.pull = _pull2.default;
exports.push = _push2.default;

},{"./getFileName.js":1,"./openOSXApp.js":3,"./pull.js":4,"./push.js":5}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _context = require('../context');

var _context2 = _interopRequireDefault(_context);

var _framework_manager = require('../library/framework_manager');

var FrameworkManager = _interopRequireWildcard(_framework_manager);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Git File Name
 *
 * Returns the currently open and selected sketch file.
 */

exports.default = function (context) {
  (0, _context2.default)(context);
  FrameworkManager.loadContentSyncFramework();
  var main = ContentSyncPanelManager.alloc().init();
  var response = main.openOSXApp();
  log(response);
  (0, _context2.default)().document.showMessage(response);
};

},{"../context":6,"../library/framework_manager":7}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _context = require('../context');

var _context2 = _interopRequireDefault(_context);

var _framework_manager = require('../library/framework_manager');

var FrameworkManager = _interopRequireWildcard(_framework_manager);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Pull
 */

exports.default = function (context) {
  (0, _context2.default)(context);
  FrameworkManager.loadContentSyncFramework();
  var main = ContentSyncPanelManager.alloc().init();
  var response = main.pull();
  log(response);
};

},{"../context":6,"../library/framework_manager":7}],5:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _context = require('../context');

var _context2 = _interopRequireDefault(_context);

var _framework_manager = require('../library/framework_manager');

var FrameworkManager = _interopRequireWildcard(_framework_manager);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Push
 *
 */

exports.default = function (context) {
  (0, _context2.default)(context);
  FrameworkManager.loadContentSyncFramework();
  var main = ContentSyncPanelManager.alloc().init();
  var response = main.push();
  log(response);
};

},{"../context":6,"../library/framework_manager":7}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (newContext) {

  //set new context
  if (newContext) {
    context = newContext;
  }

  return context;
};

/**
 * Context
 *
 * Provides a convenient way to set and get the current command context.
 */

//store context
var context = null;

//set and get context via the same function

},{}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.loadContentSyncFramework = loadContentSyncFramework;

var _context = require('../context');

var _context2 = _interopRequireDefault(_context);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function loadContentSyncFramework() {
  loadFramework('ContentSync', 'ContentSyncPanelManager');
};

function frameworkDirectory() {
  var directory = (0, _context2.default)().scriptPath.stringByDeletingLastPathComponent();
  return directory + '/frameworks';
};

function loadFramework(frameworkName, frameworkClass) {
  var directory = frameworkDirectory();
  if (true || NSClassFromString(frameworkClass) == null) {
    var mocha = Mocha.sharedRuntime();
    if (mocha.loadFrameworkWithName_inDirectory(frameworkName, directory)) {
      return true;
    } else {
      log("ERROR LOADING " + frameworkName + " in " + directory);
      return false;
    }
  } else {
    return true;
  }
};

},{"../context":6}],8:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SketchContentSyncExtension = undefined;

var _commands = require('./commands');

var commands = _interopRequireWildcard(_commands);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var SketchContentSyncExtension = exports.SketchContentSyncExtension = {
  name: 'SketchContentSync',
  bundleName: 'SketchContentSync',
  description: 'Abstract, version, and translate your design content. Sync to Google Documents and more.',
  author: 'Syncify',
  authorEmail: 'support@contentsync.io',
  version: '2.0.1',
  identifier: 'com.syncify.sketch.contentsync',
  compatibleVersion: '3.7',
  repository: {
    url: 'https://github.com/contentsync/SketchContentSync'
  },
  menu: {
    "title": "Toggle ContentSync",
    "isRoot": true,
    "items": ["commandOpenOSXApp"]
  },
  commands: {
    commandPull: {
      run: commands.pull
    },
    commandPush: {
      run: commands.push
    },
    commandGetFileName: {
      run: commands.getFileName
    },
    commandOpenOSXApp: {
      name: 'Toggle ContentSync',
      shortcut: 'cmd =',
      run: commands.openOSXApp
    }
  }
}; /**
    * Plugin
    *
    * Defines the plugin structure and metadata.
    */

__globals.___commandPull_run_handler_ = function (context, params) {
  SketchContentSyncExtension.commands['commandPull'].run(context, params);
};

__globals.___commandPush_run_handler_ = function (context, params) {
  SketchContentSyncExtension.commands['commandPush'].run(context, params);
};

__globals.___commandGetFileName_run_handler_ = function (context, params) {
  SketchContentSyncExtension.commands['commandGetFileName'].run(context, params);
};

__globals.___commandOpenOsxApp_run_handler_ = function (context, params) {
  SketchContentSyncExtension.commands['commandOpenOSXApp'].run(context, params);
};

/*__$begin_of_manifest_
{
    "name": "SketchContentSync",
    "bundleName": "SketchContentSync",
    "description": "Abstract, version, and translate your design content. Sync to Google Documents and more.",
    "author": "Syncify",
    "authorEmail": "support@contentsync.io",
    "version": "2.0.1",
    "identifier": "com.syncify.sketch.contentsync",
    "compatibleVersion": "3.7",
    "repository": {
        "url": "https://github.com/contentsync/SketchContentSync"
    },
    "menu": {
        "title": "Toggle ContentSync",
        "isRoot": true,
        "items": [
            "commandOpenOSXApp"
        ]
    },
    "commands": [
        {
            "identifier": "commandPull",
            "handler": "___commandPull_run_handler_",
            "script": "plugin.js"
        },
        {
            "identifier": "commandPush",
            "handler": "___commandPush_run_handler_",
            "script": "plugin.js"
        },
        {
            "identifier": "commandGetFileName",
            "handler": "___commandGetFileName_run_handler_",
            "script": "plugin.js"
        },
        {
            "identifier": "commandOpenOSXApp",
            "handler": "___commandOpenOsxApp_run_handler_",
            "script": "plugin.js",
            "name": "Toggle ContentSync",
            "shortcut": "cmd ="
        }
    ],
    "disableCocoaScriptPreprocessor": true
}__$end_of_manifest_
*/

},{"./commands":2}]},{},[8])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvY29tbWFuZHMvZ2V0RmlsZU5hbWUuanMiLCJzcmMvY29tbWFuZHMvaW5kZXguanMiLCJzcmMvY29tbWFuZHMvb3Blbk9TWEFwcC5qcyIsInNyYy9jb21tYW5kcy9wdWxsLmpzIiwic3JjL2NvbW1hbmRzL3B1c2guanMiLCJzcmMvY29udGV4dC5qcyIsInNyYy9saWJyYXJ5L2ZyYW1ld29ya19tYW5hZ2VyLmpzIiwic3JjL3BsdWdpbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztBQ01BOzs7O0FBQ0E7O0lBQVksZ0I7Ozs7OztBQVBaOzs7Ozs7a0JBU2UsVUFBQyxPQUFELEVBQWE7QUFDMUIseUJBQVEsT0FBUjtBQUNBLG1CQUFpQix3QkFBakI7QUFDQSxNQUFJLE9BQU8sd0JBQXdCLEtBQXhCLEdBQWdDLElBQWhDLEVBQVg7QUFDQSxNQUFJLFdBQVcsS0FBSyxXQUFMLEVBQWY7QUFDQSxNQUFJLFFBQUo7QUFDRCxDOzs7Ozs7Ozs7O0FDZkQ7Ozs7QUFDQTs7OztBQUNBOzs7O0FBQ0E7Ozs7OztRQUlFLFc7UUFDQSxVO1FBQ0EsSTtRQUNBLEk7Ozs7Ozs7OztBQ0pGOzs7O0FBQ0E7O0lBQVksZ0I7Ozs7OztBQVBaOzs7Ozs7a0JBU2UsVUFBQyxPQUFELEVBQWE7QUFDMUIseUJBQVEsT0FBUjtBQUNBLG1CQUFpQix3QkFBakI7QUFDQSxNQUFJLE9BQU8sd0JBQXdCLEtBQXhCLEdBQWdDLElBQWhDLEVBQVg7QUFDQSxNQUFJLFdBQVcsS0FBSyxVQUFMLEVBQWY7QUFDQSxNQUFJLFFBQUo7QUFDQSwyQkFBVSxRQUFWLENBQW1CLFdBQW5CLENBQStCLFFBQS9CO0FBQ0QsQzs7Ozs7Ozs7O0FDWkQ7Ozs7QUFDQTs7SUFBWSxnQjs7Ozs7O0FBTFo7Ozs7a0JBT2UsVUFBQyxPQUFELEVBQWE7QUFDMUIseUJBQVEsT0FBUjtBQUNBLG1CQUFpQix3QkFBakI7QUFDQSxNQUFJLE9BQU8sd0JBQXdCLEtBQXhCLEdBQWdDLElBQWhDLEVBQVg7QUFDQSxNQUFJLFdBQVcsS0FBSyxJQUFMLEVBQWY7QUFDQSxNQUFJLFFBQUo7QUFDRCxDOzs7Ozs7Ozs7QUNSRDs7OztBQUNBOztJQUFZLGdCOzs7Ozs7QUFOWjs7Ozs7a0JBUWUsVUFBQyxPQUFELEVBQWE7QUFDMUIseUJBQVEsT0FBUjtBQUNBLG1CQUFpQix3QkFBakI7QUFDQSxNQUFJLE9BQU8sd0JBQXdCLEtBQXhCLEdBQWdDLElBQWhDLEVBQVg7QUFDQSxNQUFJLFdBQVcsS0FBSyxJQUFMLEVBQWY7QUFDQSxNQUFJLFFBQUo7QUFDRCxDOzs7Ozs7Ozs7a0JDSmMsVUFBVSxVQUFWLEVBQXNCOztBQUVuQztBQUNBLE1BQUksVUFBSixFQUFnQjtBQUNkLGNBQVUsVUFBVjtBQUNEOztBQUVELFNBQU8sT0FBUDtBQUNELEM7O0FBbEJEOzs7Ozs7QUFNQTtBQUNBLElBQUksVUFBVSxJQUFkOztBQUVBOzs7Ozs7OztRQ05nQix3QixHQUFBLHdCOztBQUZoQjs7Ozs7O0FBRU8sU0FBUyx3QkFBVCxHQUFtQztBQUN4QyxnQkFBYyxhQUFkLEVBQTZCLHlCQUE3QjtBQUNEOztBQUVELFNBQVMsa0JBQVQsR0FBNkI7QUFDM0IsTUFBSSxZQUFZLHlCQUFVLFVBQVYsQ0FBcUIsaUNBQXJCLEVBQWhCO0FBQ0EsU0FBTyxZQUFZLGFBQW5CO0FBQ0Q7O0FBRUQsU0FBUyxhQUFULENBQXVCLGFBQXZCLEVBQXNDLGNBQXRDLEVBQXNEO0FBQ3BELE1BQUksWUFBWSxvQkFBaEI7QUFDQSxNQUFJLFFBQVEsa0JBQWtCLGNBQWxCLEtBQXFDLElBQWpELEVBQXVEO0FBQ3JELFFBQUksUUFBUSxNQUFNLGFBQU4sRUFBWjtBQUNBLFFBQUcsTUFBTSxpQ0FBTixDQUF3QyxhQUF4QyxFQUF1RCxTQUF2RCxDQUFILEVBQXFFO0FBQ25FLGFBQU8sSUFBUDtBQUNELEtBRkQsTUFFTztBQUNMLFVBQUksbUJBQW1CLGFBQW5CLEdBQW1DLE1BQW5DLEdBQTRDLFNBQWhEO0FBQ0EsYUFBTyxLQUFQO0FBQ0Q7QUFDRixHQVJELE1BUU87QUFDTCxXQUFPLElBQVA7QUFDRDtBQUNGOzs7Ozs7Ozs7O0FDbEJEOztJQUFZLFE7Ozs7QUFFTCxJQUFNLGtFQUE2QjtBQUN4QyxRQUFNLG1CQURrQztBQUV4QyxjQUFZLG1CQUY0QjtBQUd4QyxlQUFhLDBGQUgyQjtBQUl4QyxVQUFRLFNBSmdDO0FBS3hDLGVBQWEsd0JBTDJCO0FBTXhDLFdBQVMsT0FOK0I7QUFPeEMsY0FBWSxnQ0FQNEI7QUFReEMscUJBQW1CLEtBUnFCO0FBU3hDLGNBQVk7QUFDVixTQUFLO0FBREssR0FUNEI7QUFZeEMsUUFBSztBQUNILGFBQVEsb0JBREw7QUFFSCxjQUFTLElBRk47QUFHSCxhQUFRLENBQ04sbUJBRE07QUFITCxHQVptQztBQW1CeEMsWUFBVTtBQUNSLGlCQUFhO0FBQ1gsV0FBSyxTQUFTO0FBREgsS0FETDtBQUlSLGlCQUFhO0FBQ1gsV0FBSyxTQUFTO0FBREgsS0FKTDtBQU9SLHdCQUFvQjtBQUNsQixXQUFLLFNBQVM7QUFESSxLQVBaO0FBVVIsdUJBQW1CO0FBQ2pCLFlBQU0sb0JBRFc7QUFFakIsZ0JBQVUsT0FGTztBQUdqQixXQUFLLFNBQVM7QUFIRztBQVZYO0FBbkI4QixDQUFuQyxDLENBVFAiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLyoqXG4gKiBHaXQgRmlsZSBOYW1lXG4gKlxuICogUmV0dXJucyB0aGUgY3VycmVudGx5IG9wZW4gYW5kIHNlbGVjdGVkIHNrZXRjaCBmaWxlLlxuICovXG5cbmltcG9ydCBDb250ZXh0IGZyb20gJy4uL2NvbnRleHQnXG5pbXBvcnQgKiBhcyBGcmFtZXdvcmtNYW5hZ2VyIGZyb20gJy4uL2xpYnJhcnkvZnJhbWV3b3JrX21hbmFnZXInXG5cbmV4cG9ydCBkZWZhdWx0IChjb250ZXh0KSA9PiB7XG4gIENvbnRleHQoY29udGV4dClcbiAgRnJhbWV3b3JrTWFuYWdlci5sb2FkQ29udGVudFN5bmNGcmFtZXdvcmsoKTtcbiAgbGV0IG1haW4gPSBDb250ZW50U3luY1BhbmVsTWFuYWdlci5hbGxvYygpLmluaXQoKTtcbiAgbGV0IHJlc3BvbnNlID0gbWFpbi5nZXRGaWxlTmFtZSgpO1xuICBsb2cocmVzcG9uc2UpO1xufVxuIiwiaW1wb3J0IGdldEZpbGVOYW1lIGZyb20gJy4vZ2V0RmlsZU5hbWUuanMnXG5pbXBvcnQgb3Blbk9TWEFwcCBmcm9tICcuL29wZW5PU1hBcHAuanMnXG5pbXBvcnQgcHVsbCBmcm9tICcuL3B1bGwuanMnXG5pbXBvcnQgcHVzaCBmcm9tICcuL3B1c2guanMnXG5cblxuZXhwb3J0IHtcbiAgZ2V0RmlsZU5hbWUsXG4gIG9wZW5PU1hBcHAsXG4gIHB1bGwsXG4gIHB1c2hcbn1cbiIsIi8qKlxuICogR2l0IEZpbGUgTmFtZVxuICpcbiAqIFJldHVybnMgdGhlIGN1cnJlbnRseSBvcGVuIGFuZCBzZWxlY3RlZCBza2V0Y2ggZmlsZS5cbiAqL1xuXG5pbXBvcnQgQ29udGV4dCBmcm9tICcuLi9jb250ZXh0J1xuaW1wb3J0ICogYXMgRnJhbWV3b3JrTWFuYWdlciBmcm9tICcuLi9saWJyYXJ5L2ZyYW1ld29ya19tYW5hZ2VyJ1xuXG5leHBvcnQgZGVmYXVsdCAoY29udGV4dCkgPT4ge1xuICBDb250ZXh0KGNvbnRleHQpXG4gIEZyYW1ld29ya01hbmFnZXIubG9hZENvbnRlbnRTeW5jRnJhbWV3b3JrKCk7XG4gIGxldCBtYWluID0gQ29udGVudFN5bmNQYW5lbE1hbmFnZXIuYWxsb2MoKS5pbml0KCk7XG4gIGxldCByZXNwb25zZSA9IG1haW4ub3Blbk9TWEFwcCgpO1xuICBsb2cocmVzcG9uc2UpO1xuICBDb250ZXh0KCkuZG9jdW1lbnQuc2hvd01lc3NhZ2UocmVzcG9uc2UpO1xufVxuIiwiLyoqXG4gKiBQdWxsXG4gKi9cblxuaW1wb3J0IENvbnRleHQgZnJvbSAnLi4vY29udGV4dCdcbmltcG9ydCAqIGFzIEZyYW1ld29ya01hbmFnZXIgZnJvbSAnLi4vbGlicmFyeS9mcmFtZXdvcmtfbWFuYWdlcidcblxuZXhwb3J0IGRlZmF1bHQgKGNvbnRleHQpID0+IHtcbiAgQ29udGV4dChjb250ZXh0KVxuICBGcmFtZXdvcmtNYW5hZ2VyLmxvYWRDb250ZW50U3luY0ZyYW1ld29yaygpO1xuICBsZXQgbWFpbiA9IENvbnRlbnRTeW5jUGFuZWxNYW5hZ2VyLmFsbG9jKCkuaW5pdCgpO1xuICBsZXQgcmVzcG9uc2UgPSBtYWluLnB1bGwoKTtcbiAgbG9nKHJlc3BvbnNlKTtcbn1cbiIsIi8qKlxuICogUHVzaFxuICpcbiAqL1xuXG5pbXBvcnQgQ29udGV4dCBmcm9tICcuLi9jb250ZXh0JztcbmltcG9ydCAqIGFzIEZyYW1ld29ya01hbmFnZXIgZnJvbSAnLi4vbGlicmFyeS9mcmFtZXdvcmtfbWFuYWdlcic7XG5cbmV4cG9ydCBkZWZhdWx0IChjb250ZXh0KSA9PiB7XG4gIENvbnRleHQoY29udGV4dClcbiAgRnJhbWV3b3JrTWFuYWdlci5sb2FkQ29udGVudFN5bmNGcmFtZXdvcmsoKTtcbiAgbGV0IG1haW4gPSBDb250ZW50U3luY1BhbmVsTWFuYWdlci5hbGxvYygpLmluaXQoKTtcbiAgbGV0IHJlc3BvbnNlID0gbWFpbi5wdXNoKCk7XG4gIGxvZyhyZXNwb25zZSk7XG59XG4iLCIvKipcbiAqIENvbnRleHRcbiAqXG4gKiBQcm92aWRlcyBhIGNvbnZlbmllbnQgd2F5IHRvIHNldCBhbmQgZ2V0IHRoZSBjdXJyZW50IGNvbW1hbmQgY29udGV4dC5cbiAqL1xuXG4vL3N0b3JlIGNvbnRleHRcbmxldCBjb250ZXh0ID0gbnVsbFxuXG4vL3NldCBhbmQgZ2V0IGNvbnRleHQgdmlhIHRoZSBzYW1lIGZ1bmN0aW9uXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiAobmV3Q29udGV4dCkge1xuXG4gIC8vc2V0IG5ldyBjb250ZXh0XG4gIGlmIChuZXdDb250ZXh0KSB7XG4gICAgY29udGV4dCA9IG5ld0NvbnRleHRcbiAgfVxuXG4gIHJldHVybiBjb250ZXh0XG59XG4iLCJcbmltcG9ydCBDb250ZXh0IGZyb20gJy4uL2NvbnRleHQnO1xuXG5leHBvcnQgZnVuY3Rpb24gbG9hZENvbnRlbnRTeW5jRnJhbWV3b3JrKCl7XG4gIGxvYWRGcmFtZXdvcmsoJ0NvbnRlbnRTeW5jJywgJ0NvbnRlbnRTeW5jUGFuZWxNYW5hZ2VyJyk7XG59O1xuXG5mdW5jdGlvbiBmcmFtZXdvcmtEaXJlY3RvcnkoKXtcbiAgbGV0IGRpcmVjdG9yeSA9IENvbnRleHQoKS5zY3JpcHRQYXRoLnN0cmluZ0J5RGVsZXRpbmdMYXN0UGF0aENvbXBvbmVudCgpO1xuICByZXR1cm4gZGlyZWN0b3J5ICsgJy9mcmFtZXdvcmtzJztcbn07XG5cbmZ1bmN0aW9uIGxvYWRGcmFtZXdvcmsoZnJhbWV3b3JrTmFtZSwgZnJhbWV3b3JrQ2xhc3MpIHtcbiAgbGV0IGRpcmVjdG9yeSA9IGZyYW1ld29ya0RpcmVjdG9yeSgpO1xuICBpZiAodHJ1ZSB8fCBOU0NsYXNzRnJvbVN0cmluZyhmcmFtZXdvcmtDbGFzcykgPT0gbnVsbCkge1xuICAgIHZhciBtb2NoYSA9IE1vY2hhLnNoYXJlZFJ1bnRpbWUoKTtcbiAgICBpZihtb2NoYS5sb2FkRnJhbWV3b3JrV2l0aE5hbWVfaW5EaXJlY3RvcnkoZnJhbWV3b3JrTmFtZSwgZGlyZWN0b3J5KSl7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgbG9nKFwiRVJST1IgTE9BRElORyBcIiArIGZyYW1ld29ya05hbWUgKyBcIiBpbiBcIiArIGRpcmVjdG9yeSk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59O1xuIiwiLyoqXG4gKiBQbHVnaW5cbiAqXG4gKiBEZWZpbmVzIHRoZSBwbHVnaW4gc3RydWN0dXJlIGFuZCBtZXRhZGF0YS5cbiAqL1xuXG5cbmltcG9ydCAqIGFzIGNvbW1hbmRzIGZyb20gJy4vY29tbWFuZHMnXG5cbmV4cG9ydCBjb25zdCBTa2V0Y2hDb250ZW50U3luY0V4dGVuc2lvbiA9IHtcbiAgbmFtZTogJ1NrZXRjaENvbnRlbnRTeW5jJyxcbiAgYnVuZGxlTmFtZTogJ1NrZXRjaENvbnRlbnRTeW5jJyxcbiAgZGVzY3JpcHRpb246ICdBYnN0cmFjdCwgdmVyc2lvbiwgYW5kIHRyYW5zbGF0ZSB5b3VyIGRlc2lnbiBjb250ZW50LiBTeW5jIHRvIEdvb2dsZSBEb2N1bWVudHMgYW5kIG1vcmUuJyxcbiAgYXV0aG9yOiAnU3luY2lmeScsXG4gIGF1dGhvckVtYWlsOiAnc3VwcG9ydEBjb250ZW50c3luYy5pbycsXG4gIHZlcnNpb246ICcyLjAuMScsXG4gIGlkZW50aWZpZXI6ICdjb20uc3luY2lmeS5za2V0Y2guY29udGVudHN5bmMnLFxuICBjb21wYXRpYmxlVmVyc2lvbjogJzMuNycsXG4gIHJlcG9zaXRvcnk6IHtcbiAgICB1cmw6ICdodHRwczovL2dpdGh1Yi5jb20vY29udGVudHN5bmMvU2tldGNoQ29udGVudFN5bmMnXG4gIH0sXG4gIG1lbnU6e1xuICAgIFwidGl0bGVcIjpcIlRvZ2dsZSBDb250ZW50U3luY1wiLFxuICAgIFwiaXNSb290XCI6dHJ1ZSxcbiAgICBcIml0ZW1zXCI6W1xuICAgICAgXCJjb21tYW5kT3Blbk9TWEFwcFwiXG4gICAgXVxuICB9LFxuICBjb21tYW5kczoge1xuICAgIGNvbW1hbmRQdWxsOiB7XG4gICAgICBydW46IGNvbW1hbmRzLnB1bGxcbiAgICB9LFxuICAgIGNvbW1hbmRQdXNoOiB7XG4gICAgICBydW46IGNvbW1hbmRzLnB1c2hcbiAgICB9LFxuICAgIGNvbW1hbmRHZXRGaWxlTmFtZToge1xuICAgICAgcnVuOiBjb21tYW5kcy5nZXRGaWxlTmFtZVxuICAgIH0sXG4gICAgY29tbWFuZE9wZW5PU1hBcHA6IHtcbiAgICAgIG5hbWU6ICdUb2dnbGUgQ29udGVudFN5bmMnLFxuICAgICAgc2hvcnRjdXQ6ICdjbWQgPScsXG4gICAgICBydW46IGNvbW1hbmRzLm9wZW5PU1hBcHBcbiAgICB9XG4gIH1cbn1cbiJdfQ==
